#Get unique time of events
awk -F '|' '{print $1}' ./log | sort -u > event_time
 
#Filter login info
grep "user logged in" ./log > logged_in

#Filter log off info
grep "user logged off" ./log > logged_off

#Filter password change info
grep "user changed password" ./log > cgpwd

#Find time that user login, password change and log off occur
cat event_time | while read line 
do
   if grep -q "$line" logged_in; then
      if grep -q "$line" cgpwd; then 
          if grep -q "$line" logged_off; then
#Get the number of the user profiles that perform all 3 actions at a given time  
                 size=$(grep "$line" ./log | awk -F '|' '{print $3}' | awk '!x[$0]++' | wc -l)
#If it is more than 1 then it is not a bot but if it is 1...
		 if [ $size -eq 1 ]; then
#Register the user as a threat
                    user=$(grep "$line" ./log | awk -F '|' '{print $3}' | awk '!x[$0]++')
#Get the unique actions performed by the user without changing the order  
                    actions=$(grep "$line" ./log | awk -F '|' '{print $5}' | awk '!x[$0]++' | xargs )
                    valid="user logged in user changed password user logged off"
#If the actions matches the criteria then the user is a bot 
		    if [ "$actions" == "$valid" ]; then 
#Display Result
                       echo -e "\e[33m$line\e[0m"
                       echo "$user | $actions"
                    fi
                 fi
          fi
       fi
   fi
done

rm -f event_time && rm -f logged_in && rm -f logged_off && rm -f cgpwd 
